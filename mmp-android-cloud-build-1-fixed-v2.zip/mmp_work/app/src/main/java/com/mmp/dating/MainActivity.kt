package com.mmp.dating

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF0B0B0B)
private val Gold = Color(0xFFD4AF37)
private val Cream = Color(0xFFF5EFE3)
private val Muted = Color(0xFFB9B1A3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MmpApp() }
    }
}

@Composable
fun MmpApp() {
    val screen = remember { mutableStateOf("welcome") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Black, surface = Color(0xFF151515),
        onBackground = Cream, onSurface = Cream
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            when (screen.value) {
                "welcome" -> Welcome { screen.value = "discover" }
                "discover" -> Discover({ screen.value = "chat" }, { screen.value = "profile" })
                "chat" -> Chat { screen.value = "discover" }
                "profile" -> Profile { screen.value = "discover" }
            }
        }
    }
}

@Composable
fun Welcome(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("mmp", color = Gold, fontSize = 48.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Meet someone worth knowing.", color = Cream, fontSize = 20.sp)
        Spacer(Modifier.height(42.dp))
        Button(onStart, colors = ButtonDefaults.buttonColors(Gold, Black),
            shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Enter mmp", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Discover(onChat: () -> Unit, onProfile: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text("Discover", color = Cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onProfile) { Text("Profile", color = Gold) }
        }
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth().weight(1f), RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(Color(0xFF191919))) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Bottom) {
                Text("Amara, 27", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Travel • Music • Good conversation", color = Muted)
                Spacer(Modifier.height(22.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    OutlinedButton(onClick = {}) { Text("PASS") }
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(Gold, Black)) { Text("♥ LIKE") }
                    OutlinedButton(onClick = {}) { Text("★") }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onChat,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(Color(0xFF252525))
        ) {
            Text("Open Matches & Chat", color = Cream)
        }
    }
}

@Composable
fun Chat(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("‹ Back", color = Gold) }
        Text("Chat", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF151515), RoundedCornerShape(20.dp)).padding(18.dp)) {
            Column {
                Text("Amara", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Text("Hi! Nice to meet you 😊", color = Cream)
                Spacer(Modifier.height(12.dp))
                Text("Hey Amara, nice to meet you too.", color = Cream)
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField("", {}, Modifier.fillMaxWidth(), placeholder = { Text("Write a message…", color = Muted) })
    }
}

@Composable
fun Profile(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        TextButton(onClick = onBack) { Text("‹ Back", color = Gold) }
        Spacer(Modifier.height(18.dp))
        Text("My Profile", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(28.dp))
        Text("Your profile is ready for mmp.", color = Muted)
        Spacer(Modifier.height(22.dp))
        Text("Name", color = Gold)
        Text("Your Name", color = Cream, fontSize = 18.sp)
        Spacer(Modifier.height(14.dp))
        Text("Bio", color = Gold)
        Text("Tell people what makes you you.", color = Cream, fontSize = 18.sp)
        Spacer(Modifier.height(28.dp))
        Button(
        onClick = {},
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(Gold, Black)
    ) {
            Text("Edit Profile")
        }
    }
}
