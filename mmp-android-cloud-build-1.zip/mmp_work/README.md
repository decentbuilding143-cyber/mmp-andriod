mmp Android prototype
Package: com.mmp.dating
Version 1.0

This project is an offline prototype. It is not yet connected to Firebase.
A computer/build service is required to compile the source into an APK.
