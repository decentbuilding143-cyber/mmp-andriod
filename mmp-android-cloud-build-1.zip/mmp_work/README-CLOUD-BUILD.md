# MMP Android APK — phone-only cloud build

Package name: `com.mmp.dating`
Version: `1.0`

## Build the APK from an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds a debug APK in the cloud and saves it as a downloadable workflow artifact.

### Steps

1. Create/sign in to a GitHub account in your phone browser or the GitHub app.
2. Create a new repository named `mmp-android` (a public repository is simplest for a free account).
3. Upload **all contents of this ZIP** to the repository, preserving folders. In particular, `.github/workflows/build-apk.yml` must be present.
4. Open the repository → **Actions** → **Build MMP APK**.
5. Tap **Run workflow** if it has not already started.
6. Wait for the run to finish with a green check.
7. Open that workflow run and scroll to **Artifacts**.
8. Download **MMP-APK**. It contains `MMP-v1.0-debug.apk`.
9. Open the APK on your Android phone and allow installation from that source if Android asks.

The debug APK is intended for testing and direct installation. A Play Store release should use a properly signed release build and an Android App Bundle (AAB).
